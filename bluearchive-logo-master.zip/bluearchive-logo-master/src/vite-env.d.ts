/// <reference types="vite/client" />

interface Window {
  halo: HTMLImageElement;
  cross: HTMLImageElement;
}
