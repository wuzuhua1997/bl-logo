# BlueArchive-style Logo Generator

A logo generator using canvas & Vanilla js.

## Used Fonts

* [RoG2サンセリフStd B](https://www.morisawa.co.jp/fonts/specimen/1646) (Modded)

* [Wêlai Glow Sans Heavy](https://github.com/welai/glow-sans)

## Todo

* Support Hangul

* Slice font